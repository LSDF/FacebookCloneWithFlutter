// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables, sort_child_properties_last

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:test/homepage.dart';

class Homepage extends StatefulWidget {
  const Homepage({super.key});

  @override
  State<Homepage> createState() => _HomepageState();
}

class _HomepageState extends State<Homepage>
    with SingleTickerProviderStateMixin {
      
  late final TabController tabController;

  @override
  void initState() {
    tabController = TabController(length: 6, vsync: this);
    super.initState();
  }

  @override
  void dispose() {
    tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final double s = 30;
    final double a = 40;
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'facebook',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Color.fromARGB(255, 15, 121, 207),
            fontSize: s,
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Icon(
              Icons.search,
              size: s,
            ),
          )
        ],
        bottom: TabBar(
          tabs: [
            Tab(
              icon: Icon(
                Icons.home,
                size: s,
                color: Colors.black,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.connected_tv,
                size: s,
                color: Colors.black,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.people,
                size: s,
                color: Colors.black,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.shop_2_outlined,
                size: s,
                color: Colors.black,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.notifications_active_outlined,
                size: s,
                color: Colors.black,
              ),
            ),
            Tab(
              icon: Icon(
                Icons.supervised_user_circle_outlined,
                size: s,
                color: Colors.black,
              ),
            ),
          ],
          controller: tabController,
          indicatorColor: Colors.blue,
        ),
      ),
      body: TabBarView(
        children: [
          HomePage(),
          Center(
            child: Icon(Icons.connected_tv),
          ),
          Center(
            child: Icon(Icons.people),
          ),
          Center(
            child: Icon(Icons.shop_2_outlined),
          ),
          Center(
            child: Icon(Icons.notifications_active_outlined),
          ),
          Center(
            child: Icon(Icons.supervised_user_circle_outlined),
          )
        ],
        controller: tabController,
      ),
    );
  }
}
