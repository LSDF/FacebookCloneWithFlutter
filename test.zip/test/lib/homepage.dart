// ignore_for_file: prefer_const_constructors, prefer_const_literals_to_create_immutables

import 'package:flutter/material.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      scrollDirection: Axis.vertical,
      child: Container(
        decoration: BoxDecoration(color: Colors.grey),
        child: SingleChildScrollView(
          scrollDirection: Axis.vertical,
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(0),
                child: Container(
                  color: Colors.white,
                  child: Row(
                    children: [
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: SizedBox(
                            child: ClipOval(
                          child: Image.network(
                            'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            width: 60,
                            height: 60,
                          ),
                        ) /*Icon(
                            Icons.circle,
                            size: 70,
                            //
                          ),*/
                            ),
                      ),
                      Expanded(
                        child: SizedBox(
                          height: 55,
                          width: 30,
                          child: TextField(
                            decoration: InputDecoration(
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(color: Colors.grey),
                                    borderRadius: BorderRadius.circular(40)),
                                hintText: 'Whats on your mind?'),
                            textAlignVertical: TextAlignVertical.center,
                            textCapitalization: TextCapitalization.words,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.all(8.0),
                        child: Icon(
                          Icons.bookmarks,
                          size: 40,
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 10),
                child: Container(
                  color: Colors.white,
                  child: Column(
                    children: [
                      SingleChildScrollView(
                        scrollDirection: Axis.horizontal,
                        child: Row(
                          children: [
                            Padding(
                              padding: const EdgeInsets.only(
                                  left: 8.0, top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: [
                                      Image.network(
                                        'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                        fit: BoxFit.fill,
                                        width: 100,
                                        height: 100,
                                      ),
                                      Icon(Icons.add_circle_outline),
                                      Text(
                                        "Create\n Story",
                                        style: TextStyle(
                                            fontWeight: FontWeight.bold),
                                        textAlign: TextAlign.justify,
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                        alignment: Alignment.center,
                                        child: Image.network(
                                          'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                          fit: BoxFit.cover,
                                          width: 105,
                                          height: 165,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        //child: Text('hee'),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                        alignment: Alignment.center,
                                        child: Image.network(
                                          'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                          fit: BoxFit.cover,
                                          width: 105,
                                          height: 165,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        //child: Text('hee'),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                        alignment: Alignment.center,
                                        child: Image.network(
                                          'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                          fit: BoxFit.cover,
                                          width: 105,
                                          height: 165,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        //child: Text('hee'),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                        alignment: Alignment.center,
                                        child: Image.network(
                                          'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                          fit: BoxFit.cover,
                                          width: 105,
                                          height: 165,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        //child: Text('hee'),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding:
                                  const EdgeInsets.only(top: 8.0, bottom: 8.0),
                              child: SizedBox(
                                child: Card(
                                  semanticContainer: true,
                                  clipBehavior: Clip.antiAliasWithSaveLayer,
                                  child: Column(
                                    children: <Widget>[
                                      Container(
                                        alignment: Alignment.center,
                                        child: Image.network(
                                          'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                          fit: BoxFit.cover,
                                          width: 105,
                                          height: 165,
                                        ),
                                      ),
                                      Container(
                                        alignment: Alignment.center,
                                        //child: Text('hee'),
                                      )
                                    ],
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              child: ClipOval(
                                child: Image.network(
                                  'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                  width: 60,
                                  height: 60,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Row(
                                    children: [
                                      Text(
                                        "SD Dinushan",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 95),
                                        child: SizedBox(
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.linear_scale_sharp,
                                                    size: 25,
                                                  ),
                                                  Icon(
                                                    Icons.close,
                                                    size: 25,
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "10 h",
                                      style: TextStyle(),
                                    ),
                                    Icon(Icons.people),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        child: Column(
                          children: [
                            Image.network(
                              'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SizedBox(
                                    width: 100,
                                    child: Icon(Icons.handshake),
                                  ),
                                ),
                                SizedBox(
                                    width: 100, child: Icon(Icons.comment)),
                                SizedBox(width: 100, child: Icon(Icons.share))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              child: ClipOval(
                                child: Image.network(
                                  'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                  width: 60,
                                  height: 60,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Row(
                                    children: [
                                      Text(
                                        "SD Dinushan",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 95),
                                        child: SizedBox(
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.linear_scale_sharp,
                                                    size: 25,
                                                  ),
                                                  Icon(
                                                    Icons.close,
                                                    size: 25,
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "10 h",
                                      style: TextStyle(),
                                    ),
                                    Icon(Icons.people),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        child: Column(
                          children: [
                            Image.network(
                              'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SizedBox(
                                    width: 100,
                                    child: Icon(Icons.handshake),
                                  ),
                                ),
                                SizedBox(
                                    width: 100, child: Icon(Icons.comment)),
                                SizedBox(width: 100, child: Icon(Icons.share))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              child: ClipOval(
                                child: Image.network(
                                  'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                  width: 60,
                                  height: 60,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Row(
                                    children: [
                                      Text(
                                        "SD Dinushan",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 95),
                                        child: SizedBox(
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.linear_scale_sharp,
                                                    size: 25,
                                                  ),
                                                  Icon(
                                                    Icons.close,
                                                    size: 25,
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "10 h",
                                      style: TextStyle(),
                                    ),
                                    Icon(Icons.people),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        child: Column(
                          children: [
                            Image.network(
                              'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SizedBox(
                                    width: 100,
                                    child: Icon(Icons.handshake),
                                  ),
                                ),
                                SizedBox(
                                    width: 100, child: Icon(Icons.comment)),
                                SizedBox(width: 100, child: Icon(Icons.share))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              child: ClipOval(
                                child: Image.network(
                                  'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                  width: 60,
                                  height: 60,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Row(
                                    children: [
                                      Text(
                                        "SD Dinushan",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 95),
                                        child: SizedBox(
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.linear_scale_sharp,
                                                    size: 25,
                                                  ),
                                                  Icon(
                                                    Icons.close,
                                                    size: 25,
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "10 h",
                                      style: TextStyle(),
                                    ),
                                    Icon(Icons.people),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        child: Column(
                          children: [
                            Image.network(
                              'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SizedBox(
                                    width: 100,
                                    child: Icon(Icons.handshake),
                                  ),
                                ),
                                SizedBox(
                                    width: 100, child: Icon(Icons.comment)),
                                SizedBox(width: 100, child: Icon(Icons.share))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Container(
                  decoration: BoxDecoration(color: Colors.white),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Row(
                        children: [
                          Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: SizedBox(
                              child: ClipOval(
                                child: Image.network(
                                  'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                                  width: 60,
                                  height: 60,
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(top: 10),
                                  child: Row(
                                    children: [
                                      Text(
                                        "SD Dinushan",
                                        style: TextStyle(
                                            fontSize: 20,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      Container(
                                        margin: EdgeInsets.only(left: 95),
                                        child: SizedBox(
                                          child: Column(
                                            children: [
                                              Row(
                                                children: [
                                                  Icon(
                                                    Icons.linear_scale_sharp,
                                                    size: 25,
                                                  ),
                                                  Icon(
                                                    Icons.close,
                                                    size: 25,
                                                  )
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Row(
                                  children: [
                                    Text(
                                      "10 h",
                                      style: TextStyle(),
                                    ),
                                    Icon(Icons.people),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                      SizedBox(
                        child: Column(
                          children: [
                            Image.network(
                              'https://scontent.fcmb3-2.fna.fbcdn.net/v/t39.30808-6/341348708_905413083848601_6426931154056482594_n.jpg?_nc_cat=103&ccb=1-7&_nc_sid=5f2048&_nc_eui2=AeEHjSM9gLHGfHUqq6vHPrTEf4kL0oeDODV_iQvSh4M4NUQU-bs7DxJBuEWDIidB8-gpAYmw4byiKlKgp_5MgbQl&_nc_ohc=3p0akWO-xVYAX-oljKS&_nc_zt=23&_nc_ht=scontent.fcmb3-2.fna&oh=00_AfCM95e4-4SOBXoyOg2EuNK8BNWL67lzP5M_paLTvazy5g&oe=6533B919',
                            ),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SizedBox(
                                    width: 100,
                                    child: Icon(Icons.handshake),
                                  ),
                                ),
                                SizedBox(
                                    width: 100, child: Icon(Icons.comment)),
                                SizedBox(width: 100, child: Icon(Icons.share))
                              ],
                            )
                          ],
                        ),
                      )
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
